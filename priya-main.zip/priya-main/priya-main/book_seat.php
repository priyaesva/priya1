<?php
include('db.php'); // Database connection

// Get schedule_id from the booking request
$schedule_id = $_POST['schedule_id'];
$user_id = $_SESSION['user_id']; // Assuming user is logged in
$seat_number = $_POST['seat_number']; // Get seat number from form

// Check if seats are available
$check_query = "SELECT available_seats FROM schedules WHERE schedule_id = '$schedule_id'";
$check_result = mysqli_query($conn, $check_query);
$row = mysqli_fetch_assoc($check_result);

if ($row['available_seats'] > 0) {
    // Book the seat: Insert into bookings table
    $insert_booking = "INSERT INTO bookings (user_id, schedule_id, seat_number, status) 
                       VALUES ('$user_id', '$schedule_id', '$seat_number', 'Booked')";
    mysqli_query($conn, $insert_booking);

    // Reduce available seats by 1
    $update_query = "UPDATE schedules 
                     SET available_seats = available_seats - 1 
                     WHERE schedule_id = '$schedule_id'";
    mysqli_query($conn, $update_query);

    echo "<script>alert('Seat booked successfully!'); window.location='my_bookings.php';</script>";
} else {
    echo "<script>alert('No seats available!'); window.history.back();</script>";
}

?>
