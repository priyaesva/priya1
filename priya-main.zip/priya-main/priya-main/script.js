// Example JavaScript to handle form validations and interactivity

document.addEventListener('DOMContentLoaded', function () {
    console.log("Welcome to the Bus Service site!");
});






