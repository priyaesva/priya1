<?php include('header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Booking</title>
    <!-- Add Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <style>
        body {
            background-image: url("bus1.jpg.jpg"); /* Background image URL */
          background-size: cover; /* Ensures the image covers the entire background */
            background-position: center; /* Centers the image */
            background-repeat: no-repeat; /* Prevents the image from repeating */
            background-attachment: fixed; /* Keeps the background fixed while scrolling */
            font-family: 'Arial', sans-serif;
        }

        .welcome-container {
            background-color: rgba(50, 49, 49, 0.8); /* Adds a semi-transparent white background to the welcome container */
            padding: 20px;
            border-radius: 10px;
            animation: fadeIn 1s ease-in-out; /* Fade-in animation */
        }

        .container {
            background-color: rgba(43, 40, 40, 0.8); /* Adds a semi-transparent white background to the form container */
            padding: 20px;
            border-radius: 10px;
            animation: slideIn 1s ease-in-out; /* Slide-in animation */
        }

        .form-control {
            transition: all 0.3s ease; /* Smooth transition for form fields */
        }

        .form-control:focus {
            border-color: #007bff; /* Blue border on focus */
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Glow effect on focus */
        }

        .btn-primary {
            transition: all 0.3s ease; /* Smooth transition for button */
        }

        .btn-primary:hover {
            transform: scale(1.05); /* Slightly enlarge button on hover */
            background-color: #0056b3; /* Darker blue on hover */
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <!-- Welcome Quotes with Transition -->
    <div class="welcome-container text-center mt-5" id="welcome-container">
        <h1>Welcome to Your Next Journey!</h1>
        <p>Explore the beauty of Tamil Nadu with us. Safe, reliable, and comfortable.</p>
    </div>

    <!-- Bus Search Form -->
    <div class="container mt-5">
    <form id="busSearchForm" action="available_buses.php" method="GET">
    <div class="row justify-content-center">
        <!-- Departure Dropdown -->
        <div class="col-md-3 mb-3">
            <select class="form-control" name="departure" required>
                <option value="">Select Departure</option>
                <option value="Chennai">Chennai</option>
                <option value="Coimbatore">Coimbatore</option>
                <option value="Madurai">Madurai</option>
                <option value="Trichy">Trichy</option>
                <option value="Salem">Salem</option>
                <option value="Erode">Erode</option>
                <option value="Tirunelveli">Tirunelveli</option>
                <option value="Vellore">Vellore</option>
            </select>
        </div>

        <!-- Destination Dropdown -->
        <div class="col-md-3 mb-3">
            <select class="form-control" name="destination" required>
                <option value="">Select Destination</option>
                <option value="Chennai">Chennai</option>
                <option value="Coimbatore">Coimbatore</option>
                <option value="Madurai">Madurai</option>
                <option value="Trichy">Trichy</option>
                <option value="Salem">Salem</option>
                <option value="Erode">Erode</option>
                <option value="Tirunelveli">Tirunelveli</option>
                <option value="Vellore">Vellore</option>
            </select>
        </div>

        <!-- Date Input -->
        <div class="col-md-3 mb-3">
            <input type="date" class="form-control" name="date" required 
                min="<?php echo date('Y-m-d'); ?>"
                max="<?php echo date('Y-m-d', strtotime('+3 months')); ?>">
        </div>
    </div>

    <div class="row justify-content-center">
        <!-- Bus Type Dropdown -->
        <div class="col-md-3 mb-3">
            <select class="form-control" name="bus_type" required>
                <option value="">Select Bus Type</option>
                <option value="Non-AC">Non-AC</option>
                <option value="AC">AC</option>
            </select>
        </div>

        <!-- Search Button -->
        <div class="col-md-3 mb-3">
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-search"></i> Search Bus
            </button>
        </div>
    </div>
</form>

    </div>

    <!-- Include Footer -->
    <?php include('footer.php'); ?>

    <script>
        // Wait for the page to load completely
        window.onload = function() {
            // Add the 'show' class to the welcome container for transition
            document.getElementById('welcome-container').classList.add('show');
        };
    </script>
</body>
</html>