<?php include('header.php'); ?>

<?php
// Fetch bus details, selected seats, and total amount from the previous page
$bus_id = $_POST['bus_id'] ?? null;
$seats = isset($_POST['seats']) ? explode(',', $_POST['seats']) : [];
$total_amount = $_POST['total_amount'] ?? 0;

// Get the number of passengers
$num_passengers = count($seats);
?>

<div class="container mt-5">
    <h3 class="text-center text-primary mb-4"><i class="fas fa-credit-card"></i> Payment Information</h3>
    <p class="text-center text-dark mb-4">You are about to make a payment for <?php echo $num_passengers; ?> seat(s).</p>

    <form action="payment_success.php" method="POST">
        <!-- ATM Card Number -->
        <div class="form-group">
            <label for="card_number"><i class="fas fa-credit-card"></i> ATM Card Number</label>
            <input type="text" class="form-control" id="card_number" name="card_number" required maxlength="19" placeholder="Enter 16-digit ATM card number" pattern="\d{4} \d{4} \d{4} \d{4}" oninput="formatCardNumber()" />
        </div>

        <!-- Expiry Date -->
        <div class="form-group">
            <label for="expiry_date"><i class="fas fa-calendar-alt"></i> Expiry Date (MM/YY)</label>
            <input type="text" class="form-control" id="expiry_date" name="expiry_date" required maxlength="5" placeholder="MM/YY" pattern="\d{2}/\d{2}" oninput="formatExpiryDate()" />
        </div>

        <!-- CVV -->
        <div class="form-group">
            <label for="cvv"><i class="fas fa-lock"></i> CVV (3 digits)</label>
            <input type="text" class="form-control" id="cvv" name="cvv" required maxlength="3" placeholder="Enter CVV" pattern="\d{3}" />
        </div>

        <!-- Total Amount (read-only) -->
        <div class="form-group">
            <label for="total_amount"><i class="fas fa-rupee-sign"></i> Total Amount</label>
            <input type="text" class="form-control" id="total_amount" name="total_amount" value="₹<?php echo $total_amount; ?>" readonly />
        </div>

        <!-- Hidden Fields -->
        <input type="hidden" name="bus_id" value="<?php echo $bus_id; ?>">
        <input type="hidden" name="seats" value="<?php echo implode(',', $seats); ?>">

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary btn-block mt-4">
            <i class="fas fa-check-circle"></i> Proceed to Pay
        </button>
    </form>
</div>

<script>
    // Function to format the ATM card number with spaces
    function formatCardNumber() {
        var cardNumber = document.getElementById('card_number').value.replace(/\D/g, ''); // Remove non-numeric characters
        var formatted = '';
        
        // Add spaces after every 4 digits
        for (var i = 0; i < cardNumber.length; i++) {
            if (i > 0 && i % 4 === 0) {
                formatted += ' ';
            }
            formatted += cardNumber[i];
        }
        
        document.getElementById('card_number').value = formatted;
    }

    // Function to automatically add a slash in the expiry date (MM/YY format)
    function formatExpiryDate() {
        var expiryDate = document.getElementById('expiry_date').value.replace(/\D/g, ''); // Remove non-numeric characters
        if (expiryDate.length > 2) {
            expiryDate = expiryDate.slice(0, 2) + '/' + expiryDate.slice(2, 4);
        }
        document.getElementById('expiry_date').value = expiryDate;
    }
</script>

<?php include('footer.php'); ?>

<style>
/* Background color for the page */
body {
    background-color: #f8f9fa; /* Light grey background */
    font-family: 'Arial', sans-serif;
}

/* Form styling */
.form-group {
    margin-bottom: 20px;
}

label {
    font-weight: bold;
    color: #007bff;
}

input {
    border-radius: 5px;
    border: 1px solid #007bff;
    padding: 10px;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input:focus {
    border-color: #0056b3; /* Darker blue on focus */
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Glow effect on focus */
}

/* Button style */
.btn {
    font-size: 16px;
    padding: 10px 20px;
    transition: all 0.3s ease;
}

.btn:hover {
    transform: scale(1.05); /* Slightly enlarge button on hover */
    background-color: #0056b3; /* Darker blue on hover */
}

.btn-block {
    width: 100%;
}

/* Text styling */
.text-primary {
    color: #007bff !important;
}

.text-dark {
    color: #343a40 !important;
}

/* Icons */
i {
    margin-right: 8px; /* Space between icon and text */
}

/* Animation for form container */
.container {
    animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>