<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

// Initialize search filters
$route_from = isset($_GET['route_from']) ? trim($_GET['route_from']) : '';
$route_to = isset($_GET['route_to']) ? trim($_GET['route_to']) : '';

// Prepare SQL query with filters
$query = "SELECT schedules.id AS schedule_id, buses.bus_name, buses.bus_type, 
                 schedules.route_from, schedules.route_to, schedules.travel_date, 
                 schedules.departure_time, schedules.arrival_time, schedules.price, 
                 schedules.total_seats, schedules.available_seats
          FROM schedules 
          JOIN buses ON schedules.bus_id = buses.id";

if (!empty($route_from) && !empty($route_to)) {
    $query .= " WHERE schedules.route_from = ? AND schedules.route_to = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $route_from, $route_to);
} else {
    $stmt = $conn->prepare($query);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f4f4f4; }
        .container { margin-top: 20px; }
        .table-container { background: white; padding: 20px; border-radius: 5px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .btn { margin-right: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">Bus Management</h2>
        <a href="admin_dashboard.php" class="btn btn-secondary mb-3">Back to Dashboard</a>

        <!-- Search Form -->
        <form method="GET" action="" class="mb-3 d-flex">
            <input type="text" name="route_from" class="form-control me-2" placeholder="From" value="<?php echo htmlspecialchars($route_from); ?>" required>
            <input type="text" name="route_to" class="form-control me-2" placeholder="To" value="<?php echo htmlspecialchars($route_to); ?>" required>
            <button type="submit" class="btn btn-primary">Search</button>
        </form>

        <div class="table-container">
            <h3>Existing Buses</h3>
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Bus Name</th>
                        <th>Bus Type</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Travel Date</th>
                        <th>Departure</th>
                        <th>Arrival</th>
                        <th>Price</th>
                        <th>Total Seats</th>
                        <th>Available Seats</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['schedule_id']; ?></td>
                            <td><?php echo $row['bus_name']; ?></td>
                            <td><?php echo $row['bus_type']; ?></td>
                            <td><?php echo $row['route_from']; ?></td>
                            <td><?php echo $row['route_to']; ?></td>
                            <td><?php echo $row['travel_date']; ?></td>
                            <td><?php echo $row['departure_time']; ?></td>
                            <td><?php echo $row['arrival_time']; ?></td>
                            <td><?php echo number_format($row['price'], 2); ?></td>
                            <td><?php echo $row['total_seats']; ?></td>
                            <td><?php echo $row['available_seats'] ?? 'N/A'; ?></td>
                            <td>
                                <a href="edit_schedule.php?id=<?php echo $row['schedule_id']; ?>" class="btn btn-primary">Edit</a>
                                <a href="delete_schedule.php?id=<?php echo $row['schedule_id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this schedule?');">Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
