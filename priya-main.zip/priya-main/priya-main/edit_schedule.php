<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

if (isset($_GET['id'])) {
    $schedule_id = $_GET['id'];

    // Fetch schedule details along with bus details
    $query = "SELECT s.*, b.bus_name, b.bus_type FROM schedules s 
              JOIN buses b ON s.bus_id = b.id WHERE s.id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $schedule_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $schedule = $result->fetch_assoc();

    if (!$schedule) {
        echo "Schedule not found!";
        exit();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bus_name = $_POST['bus_name'];
    $bus_type = $_POST['bus_type'];
    $route_from = $_POST['route_from'];
    $route_to = $_POST['route_to'];
    $travel_date = $_POST['travel_date'];
    $departure_time = $_POST['departure_time'];
    $arrival_time = $_POST['arrival_time'];
    $total_seats = $_POST['total_seats'];
    $price = $_POST['price'];

    // Update buses table
    $update_bus_query = "UPDATE buses SET bus_name = ?, bus_type = ? WHERE id = ?";
    $stmt = $conn->prepare($update_bus_query);
    $stmt->bind_param("ssi", $bus_name, $bus_type, $schedule['bus_id']);
    $stmt->execute();

    // Update schedules table
    $update_schedule_query = "UPDATE schedules 
                              SET route_from = ?, route_to = ?, travel_date = ?, departure_time = ?, 
                                  arrival_time = ?, total_seats = ?, price = ? 
                              WHERE id = ?";
    $stmt = $conn->prepare($update_schedule_query);
    $stmt->bind_param("sssssiid", $route_from, $route_to, $travel_date, $departure_time, 
                                    $arrival_time, $total_seats, $price, $schedule_id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Schedule updated successfully!";
        header("Location: bus_management.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Error updating schedule!";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Schedule</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        h3 {
            text-align: center;
            margin-bottom: 20px;
            color: #343a40;
        }
        .form-label {
            font-weight: bold;
        }
        .btn-container {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3>Edit Schedule</h3>

        <!-- Success/Error Messages -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php elseif (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Bus Name:</label>
                <input type="text" name="bus_name" class="form-control" value="<?php echo $schedule['bus_name']; ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Bus Type:</label>
                <select name="bus_type" class="form-control">
                    <option value="AC" <?php echo ($schedule['bus_type'] == 'AC') ? 'selected' : ''; ?>>AC</option>
                    <option value="Non-AC" <?php echo ($schedule['bus_type'] == 'Non-AC') ? 'selected' : ''; ?>>Non-AC</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">From:</label>
                <input type="text" name="route_from" class="form-control" value="<?php echo $schedule['route_from']; ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">To:</label>
                <input type="text" name="route_to" class="form-control" value="<?php echo $schedule['route_to']; ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Travel Date:</label>
                <input type="date" name="travel_date" class="form-control" value="<?php echo $schedule['travel_date']; ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Departure Time:</label>
                <input type="time" name="departure_time" class="form-control" value="<?php echo $schedule['departure_time']; ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Arrival Time:</label>
                <input type="time" name="arrival_time" class="form-control" value="<?php echo $schedule['arrival_time']; ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Total Seats:</label>
                <input type="number" name="total_seats" class="form-control" value="<?php echo $schedule['total_seats']; ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Price:</label>
                <input type="number" step="0.01" name="price" class="form-control" value="<?php echo $schedule['price']; ?>" required>
            </div>

            <div class="btn-container">
                <button type="submit" class="btn btn-primary">Update Schedule</button>
                <a href="bus_management.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>
