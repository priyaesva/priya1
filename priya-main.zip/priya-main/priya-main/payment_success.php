<?php include('header.php'); ?>

<?php
// Fetch the bus details and selected seats from POST data
$bus_id = $_POST['bus_id'] ?? null;
$seats = isset($_POST['seats']) ? explode(',', $_POST['seats']) : [];
$total_amount = $_POST['total_amount'] ?? 0;
?>

<div class="container mt-5">
    <!-- Payment Success Card -->
    <div class="card payment-success-card text-center p-4 shadow-lg" id="payment-success-card">
        <!-- Payment Success Message -->
        <div id="payment-success-message">
            <h3 class="text-success"><i class="fas fa-check-circle"></i> Payment Successful</h3>
            <p class="text-muted">Thank you for your payment! Your ticket details are being generated...</p>
        </div>

        <!-- Ticket Details (initially hidden) -->
        <div id="ticket-details" class="ticket-details mt-4" style="display: none;">
            <h4 class="text-primary"><i class="fas fa-ticket-alt"></i> Your Ticket Details</h4>
            <div class="ticket-info">
                <p><strong><i class="fas fa-bus"></i> Bus ID:</strong> <?php echo $bus_id; ?></p>
                <p><strong><i class="fas fa-users"></i> Number of Passengers:</strong> <?php echo count($seats); ?></p>
                <p><strong><i class="fas fa-chair"></i> Selected Seats:</strong> <?php echo implode(', ', $seats); ?></p>
                <p><strong><i class="fas fa-rupee-sign"></i> Total Amount Paid:</strong> ₹<?php echo $total_amount; ?></p>
            </div>
            <button class="btn btn-primary mt-3" onclick="window.print()"><i class="fas fa-print"></i> Print Ticket</button>
        </div>
    </div>
</div>

<script>
    // Show payment success message initially
    document.getElementById("payment-success-message").style.display = "block";

    // After 4 seconds, hide the success message and show the ticket details
    setTimeout(function() {
        // Hide payment success message
        document.getElementById("payment-success-message").style.display = "none";

        // Show ticket details with a fade-in animation
        document.getElementById("ticket-details").style.display = "block";
        document.getElementById("ticket-details").classList.add("fade-in");
    }, 4000); // 4 seconds delay
</script>

<?php include('footer.php'); ?>

<style>
/* Background color for the page */
body {
    background-color: #f8f9fa; /* Light grey background */
    font-family: 'Arial', sans-serif;
}

/* Payment Success Card */
.payment-success-card {
    max-width: 500px;
    margin: 0 auto;
    border: none;
    border-radius: 15px;
    background: linear-gradient(135deg, #ffffff, #f1f8ff); /* Light gradient background */
    animation: fadeIn 1s ease-in-out;
}

/* Success Message Styling */
#payment-success-message h3 {
    font-size: 28px;
    font-weight: bold;
    color: #28a745; /* Green color for success */
}

#payment-success-message p {
    font-size: 16px;
    color: #6c757d; /* Grey color for text */
}

/* Ticket Details Styling */
#ticket-details {
    display: none; /* Initially hidden */
}

.ticket-info {
    text-align: left;
    padding: 15px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.ticket-info p {
    font-size: 16px;
    margin-bottom: 10px;
}

.ticket-info strong {
    color: #007bff; /* Blue color for labels */
}

/* Fade-in Animation */
.fade-in {
    animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Button Styling */
.btn {
    font-size: 16px;
    padding: 10px 20px;
    transition: all 0.3s ease;
}

.btn:hover {
    transform: scale(1.05); /* Slightly enlarge button on hover */
    background-color: #0056b3; /* Darker blue on hover */
}

/* Icons Styling */
i {
    margin-right: 8px; /* Space between icon and text */
    color: #007bff; /* Blue color for icons */
}
</style>s