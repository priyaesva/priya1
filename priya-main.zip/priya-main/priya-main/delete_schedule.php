<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

if (isset($_GET['id'])) {
    $schedule_id = $_GET['id'];

    // Delete schedule
    $delete_query = "DELETE FROM schedules WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $schedule_id);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Schedule deleted successfully!";
    } else {
        $_SESSION['error_message'] = "Error deleting schedule!";
    }
}

header("Location: bus_management.php");
exit();
?>
