<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include('db_connection.php');

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "Invalid Bus ID!";
    header("Location: bus_management.php");
    exit();
}

$bus_id = $_GET['id'];

// Delete Bus Query
$delete_query = "DELETE FROM buses WHERE id = ?";
$stmt = $conn->prepare($delete_query);
$stmt->bind_param("i", $bus_id);

if ($stmt->execute()) {
    $_SESSION['success_message'] = "Bus deleted successfully!";
} else {
    $_SESSION['error_message'] = "Error deleting bus: " . $conn->error;
}

header("Location: bus_management.php");
exit();
?>
