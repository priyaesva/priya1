<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include('db.php'); // Include database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bus_name = trim($_POST['bus_name']);
    $bus_type = trim($_POST['bus_type']);
    $route_from = trim($_POST['route_from']);
    $route_to = trim($_POST['route_to']);
    $travel_date = $_POST['travel_date'];  // Capture the travel date
    $departure_time = $_POST['departure_time'];
    $arrival_time = $_POST['arrival_time'];
    $total_seats = intval($_POST['total_seats']);
    $price = floatval($_POST['price']);

    $conn->begin_transaction(); // Start transaction

    try {
        // Insert into buses table
        $bus_query = "INSERT INTO buses (bus_name, bus_type) VALUES (?, ?)";
        $stmt = $conn->prepare($bus_query);
        $stmt->bind_param("ss", $bus_name, $bus_type);
        
        $stmt->execute();
        $bus_id = $stmt->insert_id; // Get the last inserted bus_id

        // Insert into schedules table
        $schedule_query = "INSERT INTO schedules (bus_id, route_from, route_to, travel_date, departure_time, arrival_time, total_seats, price) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
         $stmt = $conn->prepare($schedule_query);
         $stmt->bind_param("isssssdi", $bus_id, $route_from, $route_to, $travel_date, $departure_time, $arrival_time, $total_seats, $price);

        $stmt->execute();

        $conn->commit(); // Commit transaction
        $_SESSION['success_message'] = "Bus and schedule added successfully!";
    } catch (Exception $e) {
        $conn->rollback(); // Rollback transaction on failure
        $_SESSION['error_message'] = "Error adding bus: " . $e->getMessage();
    }

    header("Location: add_bus.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add New Bus</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h3>Add New Bus</h3>

        <!-- Success/Error Messages -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php elseif (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="bus_name" class="form-control mb-2" placeholder="Bus Name" required>
            <select name="bus_type" class="form-control mb-2">
                <option value="AC">AC</option>
                <option value="Non-AC">Non-AC</option>
            </select>
            <input type="text" name="route_from" class="form-control mb-2" placeholder="From" required>
            <input type="text" name="route_to" class="form-control mb-2" placeholder="To" required>
            <input type="date" name="travel_date" class="form-control mb-2" required> <!-- Added Travel Date -->
            <input type="time" name="departure_time" class="form-control mb-2" required>
            <input type="time" name="arrival_time" class="form-control mb-2" required>
            <input type="number" name="total_seats" class="form-control mb-2" placeholder="Total Seats" required>
            <input type="number" step="0.01" name="price" class="form-control mb-2" placeholder="price" required>
            <button type="submit" class="btn btn-success">Add Bus</button>
        </form>
    </div>
</body>
</html>
